# CLAUDE.md — Compass Mockup Project

You are building **Compass** — a portfolio-quality HTML mockup of an internal
Azure DevOps analytics dashboard built in Qlik Sense.

Read this file fully before writing a single line of code.

---

## Project context

Compass is a 6-screen dashboard used by three management tiers in a Hebrew-speaking org:
- רש"צ (Team Lead), רמ"ד (Dept Head), רע"ן (Branch Head)
- Data: Azure DevOps OData → Trino → PostgreSQL → Qlik. Nightly refresh.
- Screens: Overview · Bugs · Retrospect · Builds · Releases · PRs

The mockups are **portfolio artifacts** — they must look like real production screens,
not wireframes or generic dashboards.

---

## Files to read before building each screen

| File | Read when |
|---|---|
| `spec/design-system.md` | Before every single screen — it is the source of truth for all styling |
| `spec/theme.css` | The actual Qlik theme CSS. The mockup must match it exactly |
| `spec/theme.json` | Colors, fonts, chart specs |
| `spec/compass-load-script.qvs` | Field names, table structure, what data each screen uses |
| `spec/compass-data-model.md` | Full architecture reference |
| `spec/overview-spec.md` | Overview screen content and charts |
| `spec/bugs-spec.md` | Bugs screen |
| `spec/retrospect-spec.md` | Retrospect screen |
| `spec/builds-spec.md` | Builds screen |
| `spec/releases-spec.md` | Releases screen |
| `spec/prs-spec.md` | PR screen |

---

## Output format — one file per screen

Each screen is a **single self-contained HTML file**. No build step. No external file
references except the three CDN tags and Google Fonts. Opens in Chrome with zero
console errors.

```
screens/overview.html
screens/bugs.html
screens/retrospect.html
screens/builds.html
screens/releases.html
screens/prs.html
```

### Tech stack per file
- React 18 UMD via CDN: `https://unpkg.com/react@18/umd/react.development.js`
- ReactDOM 18: `https://unpkg.com/react-dom@18/umd/react-dom.development.js`
- Babel standalone: `https://unpkg.com/@babel/standalone/babel.min.js`
- Tailwind CDN for layout utilities only: `https://cdn.tailwindcss.com`
- Google Fonts Inter: `https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap`
- All charts: hand-coded SVG inside React components
- Images: embedded as base64 data URIs (base64-encode assets/wallpaper.jpg and assets/logo.png)
- Lucide icons: implemented as inline React SVG components (see icon spec below)

---

## Design rules — NON-NEGOTIABLE

Read `spec/design-system.md` for the full spec. Summary:

### Cards are WHITE and OPAQUE
```css
background:    #ffffff
border-radius: 14px
box-shadow:    0 2px 12px rgba(0,0,0,0.08)
border:        none
overflow:      hidden
```
NO glassmorphism. NO backdrop-filter. NO transparency.
The dark wallpaper background creates the contrast. Cards sit on top of it, white.

### Fonts
- All UI text: Inter
- Numbers / IDs / durations: Inter mono-style or use `font-variant-numeric: tabular-nums`

### Colors — use exactly these, no others
- Primary accent:  `#3b82f6`
- Text primary:    `#111827`
- Text muted:      `#6b7280`
- Text axis:       `#9ca3af`
- Dividers:        `#e5e7eb`
- Zebra row:       `#f9fafb`
- Row hover:       `#eff6ff`
- Success:         `#10b981`
- Warning:         `#f59e0b`
- Error/Critical:  `#ef4444`
- Canceled:        `#9ca3af`

### Chart rules
- All charts are SVG, hand-coded, inside React components
- Gridlines: `1px solid #e5e7eb`
- Axis labels: 11px `#9ca3af`
- X axis labels on bar charts: rotate -35deg if they risk overlapping
- NO chart clipping — add sufficient padding/margin inside the SVG viewBox
- Hover on bars: `filter: brightness(0.9)`
- Hover on line dots: show tooltip (white card, 8px radius, shadow)
- Area charts: gradient fill, top opacity ~0.18, bottom 0

### Navigation sidebar
```css
width:      86px
background: #0f1a2e     /* solid deep navy */
position:   fixed left
```
- Logo: `assets/logo.png` embedded as base64, 40px, centered at top
- Nav icons: inline Lucide SVG components, 22px
- Active state: right-edge 3px bar `#0f7af8` + icon color `#0f7af8`
- Inactive: `rgba(255,255,255,0.45)`, hover pill `rgba(15,122,248,0.08)` border-radius 8px
- Tooltip on hover (right side, screen name)
- Nav order top-to-bottom:
  1. LayoutDashboard → Overview
  2. GitPullRequest  → PRs
  3. Wrench          → Builds
  4. Rocket          → Releases
  5. Bug             → Bugs
  6. RotateCcw       → Retrospect

### Filter pane (right sidebar)
```css
width:      200px
background: #ffffff
border-left: 1px solid #e5e7eb
position:   fixed right
padding:    20px 16px
```
- Filter label: 11px 600 uppercase `#6b7280`, margin-bottom 6px
- Filter control: border `1px solid #cfd8e4`, border-radius 10px, 13px Inter
- Show placeholder values — not interactive
- Filters shown depend on the screen (see each screen's spec)

### Top bar
```css
height:      56px
background:  #ffffff
border-bottom: 1px solid #e5e7eb
padding:     0 24px
display:     flex align-items: center justify-content: space-between
```
- Left: screen name 16px 700 `#111827`
- Right: "Updated 2 hours ago" 12px `#9ca3af` + refresh icon

---

## Lucide icon components

Implement each as a React functional component:

```jsx
const LayoutDashboard = ({ size = 20, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
       stroke={color} strokeWidth={1.75} strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="3" width="7" height="7"/>
    <rect x="14" y="3" width="7" height="7"/>
    <rect x="14" y="14" width="7" height="7"/>
    <rect x="3" y="14" width="7" height="7"/>
  </svg>
);
```

Implement all of these — get the paths from lucide.dev:
LayoutDashboard, GitPullRequest, Wrench, Rocket, Bug, RotateCcw,
Layers, Star, Package, CheckSquare, CheckCircle, XCircle, Clock,
AlertTriangle, BarChart2, Calendar, Users, Coffee, Zap, GitMerge,
Hourglass, ChevronDown, RefreshCw, TrendingUp, TrendingDown

---

## Animation

Stagger cards on load with CSS `@keyframes fadeInUp`:
```css
@keyframes fadeInUp {
  from { opacity: 0; transform: translateY(12px); }
  to   { opacity: 1; transform: translateY(0); }
}
```
Each card: `animation: fadeInUp 0.3s ease forwards`
Stagger: `animation-delay: calc(var(--i) * 60ms)`
Set `--i` as inline style on each card (0, 1, 2, 3 …)

---

## Build order

Build **one screen at a time** in this order:
1. `screens/overview.html`
2. `screens/bugs.html`
3. `screens/retrospect.html`
4. `screens/builds.html`
5. `screens/releases.html`
6. `screens/prs.html`

After generating each file:
1. Open it in the browser: `open screens/overview.html` or `python3 -m http.server 8080`
2. Check for console errors
3. Visually confirm: wallpaper visible, white cards on top, no SVG clipping, sidebar gold active bar
4. Fix any issues before moving to the next screen

---

## Quality bar — done means ALL of these

- [ ] Wallpaper gradient visible behind the sidebar and filter pane and in the gaps between cards
- [ ] All cards are white and opaque
- [ ] All 4 KPI cards in row 1 are exactly equal height
- [ ] All SVG charts render without any clipping — every bar, dot, and label is fully visible
- [ ] X axis labels on bar charts are rotated if they would overlap
- [ ] Sidebar shows the correct active indicator (gold bar + blue icon) for this screen
- [ ] Filter pane is visible on the right with placeholder values
- [ ] All Inter font weights load correctly
- [ ] Zero console errors in Chrome
- [ ] Hover states work on: nav items, bars, line chart dots, table rows
- [ ] Staggered fade-in animation on cards

---

## What NOT to do

- Do NOT invent field names — use only those in compass-load-script.qvs
- Do NOT use glassmorphism or backdrop-filter on cards
- Do NOT use gold (#D4A946) — it is not in the Compass theme (that was an earlier draft)
- Do NOT use Recharts or any charting library — hand-code all SVGs
- Do NOT use localStorage or sessionStorage
- Do NOT add emojis
- Do NOT add features not in the screen spec

---

## Start command

```
Read spec/design-system.md, spec/theme.css, spec/theme.json, and spec/overview-spec.md.
Then build screens/overview.html.
```
